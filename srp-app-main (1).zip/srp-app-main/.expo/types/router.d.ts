/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/_sitemap` | `/navigation/AppNavigator` | `/screens/DetailsScreen` | `/screens/Explore/ExploreScreen` | `/screens/Explore/ProfileList` | `/screens/Explore/TopicPublications` | `/screens/FollowScreen` | `/screens/Home/HomeScreen` | `/screens/Home/sectionData` | `/screens/LinksScreen` | `/screens/MyCollections` | `/screens/ProfileScreen` | `/screens/PubDetailScreen` | `/screens/SearchScreen` | `/screens/Topics/TopicHomepage`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
