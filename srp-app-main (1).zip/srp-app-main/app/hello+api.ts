export function GET(request: Request) {
  return Response.json({ hello: 'world' });
}
