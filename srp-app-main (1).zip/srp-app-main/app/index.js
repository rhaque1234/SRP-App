// root file for app views, uses AppNavigator component




import React from 'react';
import AppNavigator from './navigation/AppNavigator';
//import Login from './components/Login'

export default function App() {
  return <AppNavigator />;
}