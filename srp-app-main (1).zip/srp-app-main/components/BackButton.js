// back button w target screen prop 
// set prop or it defaults to last screen in current stack
import React from 'react';
import { TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const BackButton = ({ targetScreen }) => {
    const navigation = useNavigation();

    return (
        <TouchableOpacity
            onPress={() => {
                if (targetScreen) {
                    navigation.navigate(targetScreen);
                } else {
                    navigation.goBack();
                }
            }}
        >
            <Ionicons name="chevron-back" size={30} color='#127475' />
        </TouchableOpacity>
    );
}

export default BackButton;
