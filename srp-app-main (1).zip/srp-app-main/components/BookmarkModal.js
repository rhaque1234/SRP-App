// Use this for bookmarks functionality

import React, { useState } from 'react';
import { Modal, View, Text, Button, StyleSheet, TouchableOpacity, TouchableWithoutFeedback } from 'react-native';
import Buttons from './Buttons';
import Ionicons from 'react-native-vector-icons/Ionicons';


const Bookmark2 = ({ onImage, offImage, onToggle, title }) => {
    const [saved, setSaved] = useState(false); {/* state for whether publication is bookmarked */}
    const [modalVisible, setModalVisible] = useState(false);
    const [addRemoved, setAddedRemoved] = useState(false);

    // if bookmark is on, open the modal
    const toggleSwitch = () => {
        const newState = !saved;
        setSaved(newState);
        if (!saved) {
            setModalVisible(true);
        }
        onToggle && onToggle(newState);
    };

    // button on or off
    const addRemove = () => {
        setSaved(false);
        onToggle && onToggle(false);
    }

    const close = <Ionicons name="close" size={30}></Ionicons>
    const closeModal = () => {
        setModalVisible(false);
    };

    return (
        <View style={styles.container}>
            {/* bookmark on/off */}
            <TouchableOpacity onPress={toggleSwitch}>
                {saved ? onImage : offImage}
            </TouchableOpacity>

            <Modal
                transparent={true}
                visible={modalVisible}
                onRequestClose={() => setModalVisible(false)}
            >
                {/* Outer TouchableWithoutFeedback detects taps outside the modal */}
                <TouchableWithoutFeedback onPress={closeModal}>
                    <View style={styles.modalBackground}>
                        {/* Inner TouchableWithoutFeedback prevents clicks inside from closing the modal */}
                        <TouchableWithoutFeedback>
                            <View style={styles.modalContent}>
                                <TouchableOpacity
                                    onPress={closeModal}
                                    style={styles.closeButton}
                                >
                                    {close}
                                </TouchableOpacity>
                                <View style={styles.modalTextContainer}>
                                    <Text style={styles.modalText}>{'Add to collection'}</Text>
                                    <Text style={styles.title}>{title}</Text>
                                    <Buttons onName="Remove" offName="Add" onPress={addRemove}/>
                                </View>
                            </View>
                        </TouchableWithoutFeedback>
                    </View>
                </TouchableWithoutFeedback>
            </Modal>
        </View>
    );
};

const styles = StyleSheet.create({
    modalBackground: {      // background of the modal (around the box)
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.3)'
    },
    modalContent: {         // modal box
        backgroundColor: '#D8CDC6',
        padding: 20,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center'
    },
    modalText: {
        fontSize: 18,
        color: "#127475",
        fontWeight: 'bold',
        paddingBottom: 10
    },
    title: {
        fontSize: 16,
        color: "#562C2C",
        paddingBottom: 15
    },
    buttonContainer: {
        justifyContent: 'center',
    },
    modalTextContainer: {
        alignItems: 'center', // Center content horizontally
        justifyContent: 'center',
        width: '100%' // Ensure it uses the full width of modalContent
    },
});

export default Bookmark2;