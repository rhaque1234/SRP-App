// NOT CURRENTLY BEING USED - use BookmarkModal (Bookmark2) instead

import { View, StyleSheet, Text, TouchableOpacity, TouchableWithoutFeedback } from 'react-native';
import { useState } from 'react';
import Buttons from './Buttons'

const Bookmark = ({ onImage, offImage, onToggle }) => {
    const [saved, setSaved] = useState(false); // state for whether publication is bookmarked
    const [popup, setPopup] = useState(false);

    const toggleSwitch = () => {
        const newState = !saved;
        setSaved(newState);
        setPopup(!popup);
        onToggle && onToggle(newState);
    };

    return (
        <View style={styles.container}>
            <TouchableOpacity onPress={toggleSwitch}>
                {saved ? onImage : offImage}
            </TouchableOpacity>
            {popup && (
                <View style={styles.tooltip}>
                    <Text style={styles.tooltipText}>{saved ? 'Added' : 'Removed'}</Text>
                    <Buttons></Buttons>
                </View>
            )}
        </View>
    );
};

export default Bookmark;

const styles = StyleSheet.create({
    container: {
        position: 'relative',
    },
    tooltip: {
        top: 0, // Adjust as needed
        left: -70,
        backgroundColor: 'black',
        padding: 5,
        borderRadius: 5,
    },
    tooltipText: {
        color: 'white',
        fontSize: 12,
    },
})