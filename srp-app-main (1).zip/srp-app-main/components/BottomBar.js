// simple bottom bar graphics, no button/nav yet (7/24)
import React from 'react';
import { View, Image, StyleSheet } from 'react-native';

export default function BottomBar() {
  return (
    <View style={barStyles.container}>
      <Image source={require('../assets/images/bottom_bar_pngs/homeicon.png')} style={barStyles.icon} resizeMode="contain" />
      <Image source={require('../assets/images/bottom_bar_pngs/exploreicon.png')} style={barStyles.icon} resizeMode="contain" />
      <Image source={require('../assets/images/bottom_bar_pngs/searchicon.png')} style={barStyles.icon} resizeMode="contain" />
      <Image source={require('../assets/images/bottom_bar_pngs/profileicon.png')} style={barStyles.icon} resizeMode="contain" />
    </View>
  );
}

const barStyles = StyleSheet.create({
  container: { 
    flex: 0.12, 
    backgroundColor: '#D8CDC6',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  icon: {
    width: 24,
    height: 24,
    marginBottom: 8,
  },
});