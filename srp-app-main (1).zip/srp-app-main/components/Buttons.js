import { Pressable, Text, StyleSheet } from "react-native"
import { useState } from 'react'

const Buttons = ({onName, offName, onPress}) => {
    const [press, setPress] = useState(false);

    const onOff = () => {
        setPress(!press);
        if (onPress) {
            onPress();
        }
    }

    return (
        <Pressable
            onPress={onOff}
            style={() => [styles.button, {
                backgroundColor: press ? '#562C2C' : '#C6E3E2',
                borderWidth: 1,
                borderColor: '#562C2C'},
            ]}>
        {() => (
          <Text style={[
                styles.text,
                { color: press ? '#C6E3E2' : '#562C2C' }
            ]}>{press ? onName : offName}</Text>
        )}
      </Pressable>
    );
}

const styles = StyleSheet.create({
  button: {
      borderRadius: 8,
      paddingLeft: 15,
      paddingRight: 15,
      padding: 7,
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'row',
  },
  text: {
      textAlign: 'center',
  },
});

export default Buttons;