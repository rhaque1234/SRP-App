// simple collection component that takes in color and caption parameters
// slightly bigger than topic square, but aligns well with it
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

// Topic component
const Collection = ({ name, color }) => {
  return (
    <View style={[styles.container, { backgroundColor: color }]}>
      <Text style={styles.text}>{name}</Text>
    </View>
  );
};
//console.log("test");
// Topic styles
const styles = StyleSheet.create({
  container: {
    width: 120,
    height: 120,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 5,
    // Shadow properties for iOS
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    // Elevation property for Android
    elevation: 8,
  },
  text: {
    color: '#fff', // Assuming white text for better visibility on colored backgrounds
    textAlign: 'center',
  },
});

export default Collection;
