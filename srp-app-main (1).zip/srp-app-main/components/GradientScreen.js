import React from 'react';
import { LinearGradient } from 'expo-linear-gradient';
import allScreens from '../styles'; // Adjust the path if necessary

import BottomBar from "./BottomBar"

const withGradient = (WrappedComponent) => {
  return (props) => (
    <>
      <LinearGradient
        colors={allScreens.background}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ flex: 1 }}
      >
        <WrappedComponent {...props} />
      </LinearGradient>
    </>
  );
};

export default withGradient;
