import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, StyleSheet } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AppNavigator from '../app/navigation/AppNavigator'; // Ensure the correct import path

const LoginScreen = ({ navigation }) => {  // Ensure navigation prop is received
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false); // State to track login status

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:8080/login', {
        email,
        password
      });
      const { token, userId } = response.data;

      // Store the token and userId in AsyncStorage
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('userId', userId.toString());

      console.log("Login successful, token saved:", token);

      // Set the login status to true to show the AppNavigator
      setIsLoggedIn(true);
      
    } catch (err) {
      setError('Login failed. Please check your credentials and try again.');
    }
  };

  // Conditionally render AppNavigator if logged in, else show LoginScreen
  if (isLoggedIn) {
    return <AppNavigator />; // Render the full app with tabs
  }

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        keyboardType="email-address"
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      {error ? <Text style={{ color: 'red' }}>{error}</Text> : null}
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.button, styles.loginButton]}
        onPress={() => navigation.navigate('Signup')}  // Use navigation prop
      >
        <Text style={[styles.buttonText, styles.loginButtonText]}>Don't have an account? Sign Up</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E1EFEE',
    padding: 20,
    width: '100%',
  },
  input: {
    width: '90%',
    height: 50,
    borderColor: '#D8CDC6',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 25,
    backgroundColor: '#FFFFFF',
    fontSize: 18,
  },
  button: {
    width: '90%',
    height: 50,
    backgroundColor: '#127475',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginTop: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 5,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  loginButton: {
    backgroundColor: '#C6E3E2',
  },
  loginButtonText: {
    color: '#562C2C',
  },
});

export default LoginScreen;
