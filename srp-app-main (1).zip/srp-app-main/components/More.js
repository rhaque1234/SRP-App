// explore more button:
import React from 'react';
import { View, Text, Image, StyleSheet, Pressable } from 'react-native';
import allScreens from '../styles';

// More component
const More = ({ press }) => {
  return (
    <Pressable
      style={({ pressed }) => [
        {
          backgroundColor: pressed ? 'rgb(210, 230, 255)' : 'transparent',
        },
        styles.container,
      ]}
      onPress={press}>
      <View style={styles.shadow}>
        <View style={styles.circle}>
          <Image
            source={require('../assets/images/bottom_bar_pngs/exploreicon.png')}
            style={styles.icon}
            resizeMode="contain"
          />
        </View>
      </View>
      <Text style={styles.text}>Explore more</Text>
    </Pressable>
  );
};

// More styles
const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    margin: 20,
  },
  circle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#F0F0F0', 
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
  },
  icon: {
    width: 50,
    height: 50,
  },
  text: {
    marginTop: 10,
    fontSize: 16,
    textAlign: 'center',
    color: '#562C2C',
  },
  shadow: {
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 }, 
    shadowOpacity: 0.3, 
    shadowRadius: 4, 
  },
});

export default More;
