{/* component for each individual publication, including:
 - author
 - user profile
 - summary
 - bookmark option */}

import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useState } from "react";
import Bookmark from './Bookmarks'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Bookmark2 from './BookmarkModal'

export default function Publication({name, date, title, summary, press}) {
    const [isBookmarked, setIsBookmarked] = useState(false)
    const toggle = (newState) => {
        setIsBookmarked(newState);
    };

    const bookmarked = <MaterialIcons name="bookmark" size={30} color="#127475"/>
    const toBookmark = <MaterialIcons name="bookmark-border" size={30} color="#127475" />

    return (
        <View style={pubStyles.rect}>
            <View style={pubStyles.profile}>
                <View style={pubStyles.profile_and_photo}>
                    <Image source={require('../assets/images/favicon.png')}  style={{marginRight: 10}}/>
                    <Text>{name}</Text>
                </View>
                <Bookmark2 onImage={bookmarked} offImage={toBookmark} onToggle={toggle} title={title}/>
            </View>
            <Pressable onPress={press}>
                <View style={pubStyles.summary}>
                    <Text style={pubStyles.title}>{title}</Text>
                    <Text style={pubStyles.date}>{date}</Text>
                    <Text>{summary}</Text>
                </View>
            </Pressable>
        </View>
    );
}

const pubStyles = StyleSheet.create({
    rect: {         // entire Publications container. changed this to be consistent w other components...
        width: 170,
        height: 120,
        backgroundColor: 'white',
        //flex: 1,
        margin: 15,
        justifyContent: 'center',
        alignSelf: 'center', // Center the component
        shadowColor: 'gray',
        shadowOpacity: 30,
        shadowOffset: {
            width: 4,
            height: 4
        },
        shadowRadius: 12, 
        borderRadius: 10, 
    },
    profile: {
        backgroundColor: 'white',
        borderBottomColor: '#A59B94',
        borderBottomWidth: 1,
        padding: 5,
        paddingLeft: 10,
        paddingRight: 10,
        flexDirection: 'row',
        alignItems: 'center'
    },
    profile_and_photo: {
        flex: 1, flexDirection: 'row', alignItems: 'center'
    },
    summary: {
        backgroundColor: 'white',
        padding: 10,
    },
    title: {
        color: '#562C2C',
        fontSize: 12,
    },
    date: {
        color: '#127475',
        fontSize: 12
    }
})