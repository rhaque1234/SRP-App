import { FlatList } from "react-native"
import Publication from "./Publication";

const PublicationList = ({publications}) => {
    console.log(publications[0])
    const renderItem = ({item}) => {
        return (
            <Publication name={item.som_faculty_names} date={item.pub_date} title={item.title} summary={item.abstract}></Publication>
        );
    }

    return (
        <FlatList
            data={publications}
            renderItem={renderItem}
            keyExtractor={(item) => item.publication_id.toString()}
            numColumns={2}
            contentContainerStyle={{flexGrow: 1}}
        />
    );
}

export default PublicationList;