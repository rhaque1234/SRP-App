import React from 'react';
import { View, Text, Image, StyleSheet, ActivityIndicator } from 'react-native';
import { useRoute } from '@react-navigation/native';
import Buttons from './Buttons';
import {useFetchData} from '../useFetchData';

// New component for displaying photo, name, and position
const Researcher = ({ user_id, photo }) => { 
  // server urls here:
  const FULLNAME_URL = `http://localhost:8080/fullname/${user_id}`;
  const POSITION_URL = `http://localhost:8080/position/${user_id}`;
  const BIO_URL = `http://localhost:8080/bio/${user_id}`;

  // Fetch data hook calls here:
  const { data: dataFullName, loading: loadingFullName, error: errorFullName } = useFetchData(FULLNAME_URL);
  const { data: dataPosition, loading: loadingPosition, error: errorPosition } = useFetchData(POSITION_URL);
  const { data: dataBio, loading: loadingBio, error: errorBio } = useFetchData(BIO_URL);
  
  // loading states one call:
  if (loadingFullName || loadingPosition || loadingBio) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  // error states for all:
  if (errorFullName) {
    return <Text>Error fetching full name: {errorFullName.message}</Text>;
  }

  if (errorPosition) {
    return <Text>Error fetching position: {errorPosition.message}</Text>;
  }

  if (errorBio) {
    return <Text>Error fetching position: {errorPosition.message}</Text>;
  }

  // constants here:
  const fullName = dataFullName[0].first_name + ' ' + dataFullName[0].last_name;
  const position1 = dataPosition[0].title;

  return (
    <View style={styles.container}>
      <Image source={photo} style={styles.image} />  
      <Text style={styles.name}>{fullName}</Text> 
      <Text style={styles.position}>{position1}</Text> 
      <Buttons onName={"Following"} offName={"Follow"}/>
    </View>
  );
};

// Styles for the ProfileCard component
const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    margin: 5,
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 40, // Make it a circle
    // Shadow properties for iOS
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  name: {
    marginTop: 10,
    color: '#562C2C',
    fontSize: 16,
    textAlign: 'center',
  },
  position: {
    margin: 5,
    color: '#127475',
    fontSize: 14,
    textAlign: 'center',
  },
});

export default Researcher;
