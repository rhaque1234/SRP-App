import { Component } from 'react';
import { SearchBar } from 'react-native-elements';
import { View, Text } from 'react-native'
import allScreens from '../styles';

class SearchComp extends Component {

    // implementation for text input, canceling search, formatting
    state = {
        search: '',
    };
    updateSearch = (search) => {
        this.setState({ search });
    };

    filterList(list) {
        return list.filter(listItem => listItem.toLowerCase().includes(this.state.search.toLowerCase()));
      }

    render() {
        const { search } = this.state;
        const { visible } = this.props;

        if (!visible) {
            return null;
        }

        const list = ['Jack Zeng', 'Mark Nicolls', 'Duy Nguyen', 'Jia Liu', 'Diana Toy'];
        return (
            <View>
                <SearchBar
                    placeholder="Search..."
                    onChangeText={this.updateSearch}
                    value={search}
                    containerStyle={{backgroundColor: 'transparent', borderBottomWidth: 0, borderTopWidth: 0, flex: 1, flexDirection: 'row', maxWidth: 300}}
                    inputContainerStyle={allScreens.beigeBackground}
                    placeholderTextColor={allScreens.placeholderText.color}
                    style={allScreens.primaryText}
                />
                {this.filterList(list).map((listItem, index) => (
                    <Text key={index}>{listItem}</Text>
                ))}
            </View>
        );
    }
}

export default SearchComp;