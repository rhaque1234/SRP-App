// component for topic:
//  - photo
//  - name of topic 

import React from 'react';
import { View, Text, Image, StyleSheet, Pressable } from 'react-native';
import allScreens from '../styles';

// Topic constant
const Topic = ({ name, image, press }) => {
  const imageSource = typeof image === 'string' && image.startsWith('http')
    ? { uri: image }
    : image;

  return (
    <Pressable onPress={press} style = {styles.container}>
      <View style={styles.shadow}>
        <Image source={imageSource} style={styles.image} />
      </View>
      <Text style={allScreens.topicTitle}>{name}</Text>
    </Pressable>
  );
};

// Topic styles
const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    margin: 20,
  },
// image styles
  image: {
    width: 100, 
    height: 100, 
    borderRadius: 10,
    // Shadow properties for iOS
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    // Elevation property for Android
    elevation: 8,
  },
// text styles
  text: {
    marginTop: 5,
    textAlign: 'center',
    color: '#127475',
  },
  shadow: {
      shadowColor: '#000', // Color of the shadow
      shadowOffset: { width: 0, height: 2 }, // Offset of the shadow
      shadowOpacity: 0.3, // Opacity of the shadow
      shadowRadius: 4, // Radius of the shadow blur
  }
});

export default Topic;
