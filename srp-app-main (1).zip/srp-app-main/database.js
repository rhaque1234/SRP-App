// like import files
const mysql = require('mysql2');
const dotenv = require('dotenv');
const fs = require('fs');

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

require('dotenv').config();


// "create server"
dotenv.config();

// connect to mysql db
const pool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE,
    port: 3307
}).promise();

// func for querying db
async function queryDatabase(query, params) {
    try {
        const [rows] = await pool.query(query, params);
        return rows;
    } catch (error) {
        console.error('Database query error:', error);
        // Handle or rethrow the error as needed
    }
}



async function createUser(username, email, password) {
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const result = await queryDatabase('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)', [username, email, hashedPassword]);
        return result.insertId;
    } catch (error) {
        console.error('Error creating user:', error);
        throw error;
    }
}

// Authenticate user (login)
async function authenticateUser(email, password) {
    try {
        const users = await queryDatabase('SELECT * FROM users WHERE email = ?', [email]);
        if (users.length === 0) {
            throw new Error('User not found');
        }

        const user = users[0];
        const isValidPassword = await bcrypt.compare(password, user.password_hash);
        if (!isValidPassword) {
            throw new Error('Invalid password');
        }

        // Generate JWT token using the secret key from environment variables
        const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });

        // Return both the token and the userId
        return { token, userId: user.id };
    } catch (error) {
        console.error('Authentication error:', error);
        throw error;
    }
}




async function getNote(id) {
    return queryDatabase('SELECT * FROM notes WHERE id = ?', [id]);
}

async function getNotes() {
    return queryDatabase('SELECT * FROM notes');
}

async function getNewPubsHome() {
    return queryDatabase('SELECT * FROM publications ORDER BY pub_date DESC LIMIT 10');
}

// for testing - list of top 10 publications
async function getPublications() {
    return queryDatabase('SELECT * FROM publications LIMIT 10');
}

// -----TOPICS FUNCTIONS-----
// add a new topic that the user follows
async function followTopic(uid, topic_id) {
    return queryDatabase('INSERT INTO user_topic (user_id, topic_id, created_at, updated_at) VALUES (?, ?, NOW(), NOW())', [uid, topic_id]);
}

// check to see if you're following a certain 
async function followingTopic(uid, topic_id) {
    return queryDatabase('SELECT COUNT(*) AS count FROM user_topic WHERE user_id = ? and topic_id = ?', [uid, topic_id]);
}

// remove topic from user's following list
async function unfollowTopic(uid, topic_id) {
    console.log("I'm in the database: ", uid, topic_id)
    return queryDatabase('DELETE FROM user_topic WHERE user_id=? AND topic_id=?', [uid, topic_id])
}

// get list of topics that user follows
async function getUserTopics(uid) {
    return queryDatabase('SELECT t.id AS topic_id, t.name AS topic_name, t.image FROM topics t JOIN user_topic u ON t.id=u.topic_id WHERE u.user_id = ?;', [uid])
}

async function getAllTopics() {
    const [rows] = await pool.query('SELECT * FROM topics ORDER BY name');
    return rows;
}

async function highlightTopicPub(topic_name) {
    const t_name = `%${topic_name}%`
    return queryDatabase('SELECT pmid, title, som_faculty_names, pub_date, doi FROM publications WHERE som_departments LIKE ? ORDER BY pub_date DESC LIMIT 1;', [t_name])
}

async function getTopicPubs(topic_id) {
    return queryDatabase(('SELECT p.title, p.som_faculty_names, p.pub_date, t.publication_id FROM topic_publication t JOIN publications p on t.publication_id=p.id WHERE t.topic_id = ?'), [topic_id])
}

// from practice
async function createNote(title, content) {
    try {
        const [result] = await pool.query('INSERT INTO notes (title, contents) VALUES (?, ?)', [title, content]);
        const id = result.insertId;
        return getNote(id);
    } catch (error) {
        console.error('Error creating note:', error);
        // Handle or rethrow the error as needed
    }
}

// gets name and url column from additionalLinks db, of specific user
async function getLinkIDs(user_id) {
    fullLinks = queryDatabase('SELECT url, name FROM srp_app.additionalLinks WHERE user_id = ?', [user_id]);
    return fullLinks
}

// updating topics 
async function uploadImage(imagePath, topicName) {
    try {
        const [rows] = await pool.query(
            'UPDATE topics SET image = ? WHERE name = ?',
            [imagePath, topicName]
        );
        console.log(`Image uploaded successfully for topic: ${topicName}`);
    } catch (error) {
        console.error('Error uploading image:', error);
    }
}

// uploadImage('http://localhost:8080/images/topic_pngs/medicine.png', 'Medicine');

// gets first and last name from users db, of specific user
async function getFullName(user_id) {
    nameList = queryDatabase('SELECT first_name, last_name FROM srp_app.users WHERE id = ?', [user_id]);
    return nameList
}

// gets position from users db, of specific user
async function getPosition(user_id) {
    title = queryDatabase('SELECT title FROM srp_app.users WHERE id = ?', [user_id]);
    return title
}

// gets bio from users db, of specific user
async function getBio(user_id) {
    title = queryDatabase('SELECT bio FROM srp_app.users WHERE id = ?', [user_id]);
    return title
}

// gets all collections and details from collections db, for specific user
async function getAllCollections(user_id) {
    details = queryDatabase('SELECT name, description FROM srp_app.collections WHERE user_id = ?', [user_id]);
    return details
}

// gets public collections and details from collections db, for specific user
async function getPublicCollections(user_id) {
    details = queryDatabase('SELECT name, description FROM srp_app.collections WHERE privacy = ? AND user_id = ?', 
    ['pub', user_id]);
    return details
}


// Export functions using CommonJS
module.exports = {
    createNote,
    followTopic,
    followingTopic,
    getAllTopics,
    getNewPubsHome,
    getNote,
    getNotes,
    getPublications,
    getTopicPubs,
    createNote,
    getLinkIDs,
    getUserTopics,
    highlightTopicPub,
    unfollowTopic,
    getFullName,
    getPosition,
    getBio,
    createUser,
    authenticateUser,
    getAllCollections,
    getPublicCollections,
};

