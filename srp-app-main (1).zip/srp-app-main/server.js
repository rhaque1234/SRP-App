const express = require('express');
const { 
    followTopic,
    followingTopic,
    getAllTopics,
    getLinkIDs,
    getNewPubsHome,
    getNote,
    getNotes,
    getPublications,
    getTopicPubs,
    getUserTopics,
    highlightTopicPub,
    unfollowTopic,
    getFullName,
    getPosition,
    getBio,
    createUser,
    authenticateUser, 
    getAllCollections,
    getPublicCollections,
} = require('./database.js');

// http://localhost:8080/ beginning of link to server 

const cors = require('cors');
const fileUpload = require('express-fileupload')
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(fileUpload());
require('dotenv').config();

// -----INTERNAL SERVER FUNCTIONS-----

// for images of all topics
app.use(express.static(path.join(__dirname, 'assets')));

// new publications for the homepage
app.get('/newpubshome', async (req, res) => {
    try {
        const publications = await getNewPubsHome();
        res.json(publications);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.get('/links', async (res) => {
    try {
        const links = await getLinkIDs();
        res.json(links);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// -----TOPICS FUNCTIONS-----
// add a new topic that the user follows - MIGHT NOT NEED
app.post('/followTopic', async (req, res) => {
    const { uid, topic_id } = req.body;  // Extract from req.body
    console.log('Received data for followTopic:', uid, topic_id);
    try {
        const userTopics = await followTopic(uid, topic_id);
        res.json(userTopics);
    } catch (error) {
        console.error('Error adding user topic:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.delete('/unfollowTopic', async (req, res) => {
    const { uid, topic_id } = req.body;
    console.log('Received data for unfollowTopic:', uid, topic_id);
    try {
        const userTopics = await unfollowTopic(uid, topic_id);
        res.json(userTopics);
    } catch (error) {
        console.error('Error removing user topic:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


// Signup route
app.post('/signup', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const userId = await createUser(username, email, password);
        res.status(201).json({ message: 'User created successfully', userId });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Login route
app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const { token, userId } = await authenticateUser(email, password);
        res.json({ token, userId });
    } catch (error) {
        res.status(401).json({ error: error.message });
    }
});


// get list of topics that user follows
app.get("/getAllTopics", async (req, res) => {
    try {
        const allTopics = await getAllTopics();
        res.json(allTopics);
    } catch (error) {
        console.error('Error fetching topics:', error); // Log the error for debugging
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// get list of topics that user follows
app.get("/getUserTopics/:user_id", async (req, res) => {
    const uid = req.params.user_id;
    try {
        const userTopics = await getUserTopics(uid);
        res.json(userTopics);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.post('/followTopic', async (req, res) => {
    const { uid, topic_id } = req.body;

    if (!uid || !topic_id) {
        return res.status(400).json({ error: 'User ID and Topic ID are required' });
    }

    try {
        await followTopic(uid, topic_id);
        res.status(201).json({ message: 'Topic added to user successfully' });
    } catch (error) {
        console.error('Error adding user topic:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// get publication information for specific topic
app.get("/followingTopic/:uid/:topic_id", async (req, res) => {
    try {
        const uid = req.params.topic_id;
        const topic_id = req.params.topic_id;
        const top = await followingTopic(uid, topic_id);
        res.json(top);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// get publication information for specific topic
app.get("/getTopicPubs/:topic_id", async (req, res) => {
    try {
        const topic_id = req.params.topic_id;
        const pubList = await getTopicPubs(topic_id);
        res.json(pubList);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// get information for the featured topic on the homepage of the topic
app.get("/highlightTopicPub/:topic_id", async (req, res) => {
    try {
        const topic_id = req.params.topic_id;
        const pub = await highlightTopicPub(topic_id);
        res.json(pub);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// -----BASIC FUNCTIONS----- (archive)

// Route to get a publication by source - test
app.get('/publications/:source', async (req, res) => {
    try {
        const source = req.params.source;
        const publication = await getPub('Front Oncol');
        res.json(publication);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/note', async (req, res) => {
    try {
        const notes = await getNote('1');
        res.json(notes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
})


// practice table - not used in app
app.get("/notes", async (req, res) => {
    try {
        const notes = await getNotes();
        res.json(notes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// get 10 publications
app.get("/pubs", async (req, res) => {
    try {
        const pubs = await getPublications();
        res.json(pubs);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// new publications for the homepage
app.get('/newpubshome', async (req, res) => {
    try {
        const publications = await getNewPubsHome();
        res.json(publications);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// calls getLinkIDs
app.get('/links/:user_id', async (req, res) => {
    try {
        const user_id = req.params.user_id
        const links = await getLinkIDs(user_id);
        res.json(links);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// calls getFullName
app.get('/fullname/:user_id', async (req, res) => {
    try {
        const user_id = req.params.user_id
        const links = await getFullName(user_id);
        res.json(links);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// calls getPosition
app.get('/position/:user_id', async (req, res) => {
    try {
        const user_id = req.params.user_id
        const links = await getPosition(user_id);
        res.json(links);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// calls getBio
app.get('/bio/:user_id', async (req, res) => {
    try {
        const user_id = req.params.user_id
        const links = await getBio(user_id);
        res.json(links);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//calls getAllCollections
app.get('/allcollections/:user_id', async (req, res) => {
    try {
        const user_id = req.params.user_id
        const collections = await getAllCollections(user_id);
        res.json(collections);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


//calls getPublicCollections
app.get('/publiccollections/:user_id', async (req, res) => {
    try {
        const user_id = req.params.user_id
        const collections = await getPublicCollections(user_id);
        res.json(collections);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

app.listen(8080, () => {
    console.log("server is running on port 8080");
});
