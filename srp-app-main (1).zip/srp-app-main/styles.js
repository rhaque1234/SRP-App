import { StyleSheet } from 'react-native'

// Search and bottom bar settings
const allScreens = StyleSheet.create({
    primaryText: {     // main text (e.g. type in searchbar), icons (e.g. type in bottom bar)
        fontFamily: 'Open Sans Bold',
        color: '#562C2C'
    },
    placeholderText: {    // placeholder text for searchbar
        color: '#ba9999'
    },
    beigeBackground: {   // background color for search + bottom bar
        backgroundColor: '#D8CDC6'
    },
    background: [       // background of whole app
        '#FFFFFF',       // Starting color
        '#C6E3E2'        // Ending color
    ],
    mainTitle: {
        fontSize: 32,
        color: '#562C2C',
        fontWeight: 'bold',
        textAlign: 'center',
        padding: 10
    },
    subtitle: {
        fontSize: 22,
        color: '#562C2C',
        padding: 10
    },
    profileTitleName: {
        fontSize: 18,
        color: '#562C2C'
    },
    profileDept: {
        fontSize: 16,
        color: '#A59B94',
    },
    profilePosition: {
        fontSize: 14,
        color: '#127475'
    },
    topicTitle: {
        fontSize: 18,
        color: '#127475',
        paddingTop: 10,
        textAlign: 'center'
    }
})

export default allScreens;