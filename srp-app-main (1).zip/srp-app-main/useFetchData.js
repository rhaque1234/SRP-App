import { useEffect, useState } from 'react';
import axios from 'axios';

export function useFetchData(url) {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchDataAsync = async () => {
            try {
                const response = await axios.get(url);
                setData(response.data);
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };

        fetchDataAsync();
    }, [url]);

    return { data, loading, error };
}

export function insertData(url, data) {
    axios.post(url, data)
        .then(response => {
            console.log(response.data);
        })
        .catch(error => {
            console.error("Error sending data: ", error);
        });
}

export function deleteData(url, data) {
    axios.delete(url, {
        data: data
    })
    .then(response => {
        console.log(response.data);
    })
    .catch(error => {
        console.error("Error sending data: ", error);
    });
}

